ALTER TABLE `custom_fields` ADD `show_in_estimate` TINYINT(1) NOT NULL DEFAULT '0' AFTER `show_in_invoice`;#

ALTER TABLE `notes` ADD `files` MEDIUMTEXT CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL AFTER `labels`;#

ALTER TABLE `events` ADD `confirmed_by` TEXT NOT NULL AFTER `recurring_dates`, ADD `rejected_by` TEXT NOT NULL AFTER `confirmed_by`;#